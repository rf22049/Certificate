<!DOCTYPE html>

<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->make('partials.favicon', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    <title><?php echo e(__('Create Certificate')); ?> | ProCert</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <?php echo $__env->make('partials.theme-init', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="<?php echo e($template ? 'template-success-page' : 'template-upload-page'); ?>">
    <div class="app-shell">

        <?php echo $__env->make('partials.wizard-header', [
            'currentStep' => 1,
            'showSteps' => false,
            'showExcel' => !$template
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <main class="page-content <?php echo e($template ? 'page-content--success' : 'page-content--upload'); ?>">
            
            <?php if($template): ?>
                <section class="page-intro">
                    <h1><?php echo e(__('Template uploaded successfully!')); ?></h1>
                    <p><?php echo e(__('Make sure the uploaded design is correct.')); ?></p>
                </section>

                <?php $__errorArgs = ['template'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="form-error" role="alert"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <div class="success-layout">
                    <div class="certificate-preview" aria-label="<?php echo e(__('Certificate template preview')); ?>">
                        <?php if(str_starts_with($template['mime'], 'image/')): ?>
                        <img
                            src="<?php echo e(route('templates.preview', [
                                'v' => ($template['id'] ?? 'upload') . '-' . $template['size'] . '-' . md5($template['name']) ])); ?>"
                            alt="<?php echo e(__('Preview :name', ['name' => $template['name']])); ?>"
                        >
                        <?php else: ?>
                            <iframe src="<?php echo e(route('templates.preview')); ?>"
                                title="<?php echo e(__('Preview :name', ['name' => $template['name']])); ?>"></iframe>
                        <?php endif; ?>
                    </div>

                    <aside class="file-column" aria-label="<?php echo e(__('Uploaded template')); ?>">
                        <section class="file-panel">
                            <div class="file-panel-header">
                                
                                <span class="file-icon" aria-hidden="true">  
                                    <svg viewBox="0 0 24 24" fill="none"
                                        stroke="currentColor" stroke-width="1.8"
                                        stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M13.5 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9.5L13.5 3Z"/>
                                        <path d="M13 3v7h7M8 14h8M8 17.5h8"/>
                                    </svg>
                                </span>

                                <span class="file-panel-copy">
                                    <strong title="<?php echo e($template['name']); ?>">
                                        <?php echo e($template['name']); ?>

                                    </strong>

                                    <span>
                                        <?php echo e(number_format($template['size'] / 1024 / 1024, 1)); ?> MB
                                        &nbsp; <?php echo e($template['extension']); ?>

                                    </span>
                                </span>

                                <form method="POST" action="<?php echo e(route('templates.destroy')); ?>">
                                    
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    
                                    <button class="icon-button" type="submit"
                                            aria-label="<?php echo e(__('Delete template')); ?>"
                                            title="<?php echo e(__('Delete template')); ?>">

                                        <svg viewBox="0 0 24 24" fill="none"
                                            stroke="currentColor" stroke-width="1.7"
                                            stroke-linecap="round" stroke-linejoin="round">
                                            
                                            <path d="M4 7h16M10 11v6m4-6v6M6 7l1 14h10l1-14M9 7V4h6v3"/>
                                        </svg>
                                    </button>
                                </form>
                            </div>

                            <div class="file-panel-body">
                                <?php if(str_starts_with($template['mime'], 'image/')): ?>
                                <div class="file-thumbnail">
                                    <img
                                        src="<?php echo e(route('templates.preview', [
                                            'v' => ($template['id'] ?? 'upload') . '-' . $template['size'] . '-' . md5($template['name']) ])); ?>"
                                        alt=""
                                    >
                                </div>

                                <?php else: ?>

                                <div class="file-thumbnail file-thumbnail--pdf"
                                    aria-label="<?php echo e(__('PDF document')); ?>">
                                    <svg viewBox="0 0 24 24" fill="none"
                                        stroke="currentColor" stroke-width="1.5"
                                        stroke-linecap="round" stroke-linejoin="round">

                                        <path d="M13.5 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9.5L13.5 3Z"/>
                                        <path d="M13 3v7h7M8 15h8M8 18h5"/>
                                    </svg>
                                </div>
                                <?php endif; ?>

                                <form method="POST"
                                    action="<?php echo e(route('templates.store')); ?>"
                                    enctype="multipart/form-data"
                                    data-replace-form>

                                    <?php echo csrf_field(); ?>
                                    <input class="visually-hidden"
                                        id="replace-template"
                                        name="template"
                                        type="file"
                                        accept="image/png,image/jpeg,application/pdf"
                                        data-replace-input>

                                    <label class="replace-picker" for="replace-template">
                                        <svg viewBox="0 0 24 24" fill="none"
                                            stroke="currentColor" stroke-width="1.8"
                                            stroke-linecap="round" stroke-linejoin="round">
                                            <path d="M7 7h13l-3-3M17 17H4l3 3M20 7l-4 3M4 17l4-3"/>
                                        </svg>
                                        <?php echo e(__('Replace File')); ?>

                                    </label>
                                </form>
                            </div>
                        </section>

                        <div class="continue-area">
                            <a class="primary-button" href="<?php echo e(route('recipients.index')); ?>">
                                <?php echo e(__('Continue')); ?>

                                <svg viewBox="0 0 24 24" fill="none"
                                    stroke="currentColor" stroke-width="2"
                                    stroke-linecap="round" stroke-linejoin="round">

                                    <path d="M5 12h14M13 6l6 6-6 6"/>
                                </svg>
                            </a>
                        </div>
                    </aside>
                </div>

            <?php else: ?>

                <div class="template-home-layout">

                    <!-- SIDEBAR CARI TEMPLATE -->
                    <aside class="template-sidebar" id="templateSidebar">
                        <div class="sidebar-top">
                            <div class="sidebar-heading">
                                <span class="sidebar-eyebrow"><?php echo e(__('LIBRARY')); ?></span>
                                <h2 class="sidebar-title"><?php echo e(__('Choose a Design')); ?></h2>
                                
                                <p class="sidebar-subtitle">
                                    <?php echo e(__('Find a certificate template that suits your needs.')); ?>

                                </p>
                            </div>

                            <button type="button"
                                    class="sidebar-close"
                                    id="closeSidebar"
                                    aria-label="<?php echo e(__('Close sidebar')); ?>">
                                &times;
                            </button>
                        </div>

                        <div class="sidebar-search-wrap">
                            <span class="sidebar-search-icon">
                                <svg viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    stroke-width="2"
                                    stroke-linecap="round">
                                    <circle cx="11" cy="11" r="7"/>
                                    <path d="m16 16 4 4"/>
                                </svg>
                            </span>

                            <input type="search"
                                class="template-search"
                                id="templateSearch"
                                placeholder="<?php echo e(__('Search template names...')); ?>">
                        </div>

                        <div class="template-list" id="templateList">
                            
                            <?php $__currentLoopData = $builtinTemplates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="template-card">
                                <form method="POST"
                                    action="<?php echo e(route('templates.select', ['id' => $id])); ?>"
                                    class="template-item"
                                    data-template-name="<?php echo e(strtolower($item['name'])); ?>">

                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="template-option">
                                        <img src="<?php echo e(asset($item['path'])); ?>"
                                            alt="<?php echo e($item['name']); ?>">
                                        <span><?php echo e($item['name']); ?></span>
                                    </button>
                                </form>

                                <button type="button"
                                    class="template-preview-button"
                                    data-preview-src="<?php echo e(asset($item['path'])); ?>"
                                    data-preview-name="<?php echo e($item['name']); ?>"
                                    aria-label="<?php echo e(__('Preview :name', ['name' => $item['name']])); ?>"
                                    title="<?php echo e(__('View preview')); ?>">
                                    
                                    <svg viewBox="0 0 24 24"
                                        fill="none"
                                        stroke="currentColor"
                                        stroke-width="1.8"
                                        stroke-linecap="round"
                                        stroke-linejoin="round">

                                        <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/>
                                        <circle cx="12" cy="12" r="3"/>
                                    </svg>
                                </button>
                            </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <p class="template-empty" id="templateEmpty" hidden>
                                <?php echo e(__('No templates found.')); ?>

                            </p>
                        </div>
                    </aside>

                    <!-- TOMBOL BUKA SIDEBAR -->
                    <button type="button"
                            class="sidebar-open is-visible"
                            id="openSidebar"
                            aria-label="<?php echo e(__('Open template search')); ?>">
                        &rsaquo;
                        <span class="sidebar-open-label"><?php echo e(__('Browse Templates')); ?></span>
                    </button>

                    <!-- BAGIAN UTAMA -->
                    <div class="template-main">
                        <section class="page-intro page-intro--hero">
                            <h1><?php echo e(__('Create')); ?> <span class="title-accent"><?php echo e(__('Certificate')); ?></span></h1>
                            <p><?php echo e(__('Upload a certificate design to get started.')); ?></p>
                        </section>

                        <?php $__errorArgs = ['template'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="form-error" role="alert"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <form class="upload-card"
                            method="POST"
                            action="<?php echo e(route('templates.store')); ?>"
                            enctype="multipart/form-data"
                            data-upload-form>

                            <?php echo csrf_field(); ?>
                            <div class="dropzone" data-dropzone>

                                
                                <div class="upload-content" data-upload-content>
                                    <span class="upload-symbol" aria-hidden="true">
                                        <svg viewBox="0 0 48 48" fill="none"
                                            stroke="currentColor" stroke-width="4.5"
                                            stroke-linecap="round" stroke-linejoin="round">
                                            <rect x="3.5" y="4.5" width="41" height="39" rx="3"/>
                                            <path d="m9 35 10-11 7 8 5-6 8 9H9Z"
                                                fill="currentColor" stroke="none"/>
                                        </svg>
                                    </span>

                                    <h2><?php echo e(__('Drag & Drop File Here')); ?></h2>
                                    <p class="or-copy"><?php echo e(__('or')); ?></p>

                                    <input class="visually-hidden"
                                        id="template-file"
                                        name="template"
                                        type="file"
                                        accept="image/png,image/jpeg,application/pdf"
                                        aria-hidden="true"
                                        tabindex="-1"
                                        data-template-input>

                                    <button class="file-picker"
                                        type="button"
                                        data-file-picker>
                                        <?php echo e(__('Choose File')); ?>

                                    </button>

                                    <p class="format-copy">
                                        <?php echo e(__('Formats: PNG, JPG, or PDF')); ?><br>
                                        <?php echo e(__('Maximum size: 10 MB')); ?>

                                    </p>
                                </div>

                                
                                <div class="upload-loading" data-upload-loading hidden>
                                    <span class="upload-spinner" aria-hidden="true"></span>

                                    <h2><?php echo e(__('Uploading certificate...')); ?></h2>

                                    <p data-upload-loading-name>
                                        <?php echo e(__('Please wait while your file is being uploaded.')); ?>

                                    </p>

                                    <div class="upload-progress-track">
                                        <span></span>
                                    </div>

                                    <span class="upload-loading-caption">
                                        <?php echo e(__('Do not close this page.')); ?>

                                    </span>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        </main>

        <!-- TEMPLATE PREVIEW MODAL -->
        <div class="template-preview-modal"
            id="templatePreviewModal"
            aria-hidden="true">

            <div class="template-preview-content"
                role="dialog"
                aria-modal="true"
                aria-labelledby="templatePreviewTitle">

                <button type="button"
                    class="template-preview-close"
                    id="closeTemplatePreview"
                    aria-label="<?php echo e(__('Close preview')); ?>">
                    &times;
                </button>

                <div class="template-preview-heading"
                    id="templatePreviewTitle">
                    <?php echo e(__('Template Preview')); ?>

                </div>

                <div class="template-preview-image-wrap">
                    <img src=""
                        alt="<?php echo e(__('Certificate template preview')); ?>"
                        class="template-preview-image"
                        id="templatePreviewImage">
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const sidebar = document.getElementById('templateSidebar');
            const openButton = document.getElementById('openSidebar');
            const closeButton = document.getElementById('closeSidebar');
            const searchInput = document.getElementById('templateSearch');
            const templateItems = document.querySelectorAll('.template-item');
            const emptyMessage = document.getElementById('templateEmpty');

            if (sidebar && openButton && closeButton) {
                openButton.addEventListener('click', function () {
                    sidebar.classList.add('is-open');

                    openButton.classList.remove('is-visible');

                    sidebar.setAttribute('aria-hidden', 'false');
                    openButton.setAttribute('aria-expanded', 'true');
                });

                closeButton.addEventListener('click', function () {
                    // Mulai tutup sidebar
                    sidebar.classList.remove('is-open');

                    // Mulai munculkan tombol secara bersamaan
                    openButton.classList.add('is-visible');

                    sidebar.setAttribute('aria-hidden', 'true');
                    openButton.setAttribute('aria-expanded', 'false');
                });
            }

            if (searchInput) {
                searchInput.addEventListener('input', function () {
                    const keyword = this.value.toLowerCase().trim();
                    let visibleCount = 0;

                    templateItems.forEach(function (item) {
                        const name = item.dataset.templateName || '';
                        const matches = name.includes(keyword);
                        item.hidden = !matches;

                            if (matches) {
                                visibleCount++;
                            }
                    });

                    if (emptyMessage) {
                        emptyMessage.hidden = visibleCount !== 0;
                    }
                });
            }

            // Preview template bawaan
            const previewModal = document.getElementById('templatePreviewModal');
            const previewImage = document.getElementById('templatePreviewImage');
            const previewTitle = document.getElementById('templatePreviewTitle');
            const closePreviewButton = document.getElementById('closeTemplatePreview');
            const previewButtons = document.querySelectorAll('.template-preview-button');

            function closeTemplatePreview() {
                if (!previewModal) return;
                    previewModal.classList.remove('is-active');
                    previewModal.setAttribute('aria-hidden', 'true');
                    previewImage.src = '';
                    document.body.style.overflow = '';
            }

            previewButtons.forEach(function (button) {
                button.addEventListener('click', function () {
                    const imageSrc = this.dataset.previewSrc;
                    const templateName = this.dataset.previewName;

                    if (!previewModal || !previewImage) return;
                    previewImage.src = imageSrc;
                    previewImage.alt = window.procertTranslations.previewPrefix + ' ' + templateName;
                    previewTitle.textContent = templateName;
                    previewModal.classList.add('is-active');
                    previewModal.setAttribute('aria-hidden', 'false');
                    document.body.style.overflow = 'hidden';
                });
            });

            if (closePreviewButton) {
                    closePreviewButton.addEventListener('click', closeTemplatePreview);
            }

            if (previewModal) {
                previewModal.addEventListener('click', function (event) {
                    if (event.target === previewModal) {
                        closeTemplatePreview();
                    }
                });
            }

            document.addEventListener('keydown', function (event) {
                if (event.key === 'Escape') {
                    closeTemplatePreview();
                }
            });
        });
    </script>
</body>
</html>
<?php /**PATH C:\Users\Sora\Documents\Certificate Project\Certificate\resources\views/certificate-templates/create.blade.php ENDPATH**/ ?>