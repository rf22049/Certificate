<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(__('Edit Certificate')); ?> | ProCert</title>
    <?php echo $__env->make('partials.favicon', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400;1,500;1,600;1,700&family=Poppins:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400;1,500;1,600;1,700&family=Montserrat:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400;1,500;1,600;1,700&family=Lato:ital,wght@0,400;0,700;1,400;1,700&family=Open+Sans:ital,wght@0,400;0,600;0,700;1,400;1,600;1,700&family=Roboto:ital,wght@0,400;0,500;0,700;1,400;1,500;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,400;1,700&family=Merriweather:ital,wght@0,400;0,700;1,400;1,700&family=Nunito:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400;1,500;1,600;1,700;1,800&family=Raleway:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400;1,500;1,600;1,700;1,800&family=Oswald:wght@400;500;600;700&family=Lora:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700&family=Roboto+Slab:wght@400;500;600;700&family=DM+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">

    <?php echo $__env->make('partials.theme-init', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

        <style>
      #certificateStage { position: relative; }
      #imageLayer { position:absolute; inset:0; pointer-events:none; z-index:4; }
      .image-box-wrapper { position:absolute; pointer-events:auto; cursor:move; box-sizing:border-box; }
      .image-box-wrapper.selected { outline:2px dashed #5b5bd6; outline-offset:2px; }
      .image-box-wrapper img { width:100%; height:100%; object-fit:contain; display:block; pointer-events:none; user-select:none; }
      .image-resize-handle { position:absolute; right:-7px; bottom:-7px; width:14px; height:14px; border:2px solid white; background:#5b5bd6; border-radius:3px; cursor:nwse-resize; box-shadow:0 0 0 1px #5b5bd6; }
      .custom-element-actions { display:grid; gap:8px; }
      #imageSettingsPanel { display:none; }
      #imageSettingsPanel.active { display:block; }
      #selectedImagePreview { max-width:100%; max-height:120px; object-fit:contain; display:block; margin:8px auto; }
      .image-setting-actions { display:flex; gap:8px; flex-wrap:wrap; }
      .image-setting-actions button { flex:1; }
    </style>

</head>

<body>
    <div class="app-shell">

        <?php echo $__env->make('partials.wizard-header', ['currentStep' => 4], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <main class="edit-page" id="certificate-editor">

            <header class="edit-heading">
                <h1><?php echo e(__('Edit Certificate Design')); ?></h1>
                <p><?php echo e(__('Adjust recipient names, numbering, and certificate design before issuing.')); ?></p>
            </header>

            <section class="editor-layout">

                
                <div class="preview-panel">

                    <div class="preview-toolbar">
                        <strong><?php echo e(__('Certificate Preview')); ?></strong>

                        <div class="toolbar-group">
                            <button type="button" class="tool-button" id="undoButton" title="<?php echo e(__('Undo')); ?>" aria-label="<?php echo e(__('Undo')); ?>" disabled>↶</button>
                            <button type="button" class="tool-button" id="redoButton" title="<?php echo e(__('Redo')); ?>" aria-label="<?php echo e(__('Redo')); ?>" disabled>↷</button>
                            <button type="button" class="tool-button" id="zoomOut" title="<?php echo e(__('Zoom out')); ?>" aria-label="<?php echo e(__('Zoom out')); ?>">−</button>
                            <span class="zoom-label" id="zoomLabel">100%</span>
                            <button type="button" class="tool-button" id="zoomIn" title="<?php echo e(__('Zoom in')); ?>" aria-label="<?php echo e(__('Zoom in')); ?>">+</button>
                        </div>
                    </div>

                    <div class="preview-canvas" id="previewCanvas">
                        <div class="certificate-stage" id="certificateStage">

                            <?php if(str_starts_with($template['mime'], 'image/')): ?>
                                <img
                                    src="<?php echo e(route('templates.preview')); ?>"
                                    alt="<?php echo e(__('Certificate Template')); ?>"
                                    id="templateImage"
                                >
                            <?php elseif($template['mime'] === 'application/pdf'): ?>
                                <iframe
                                    src="<?php echo e(route('templates.preview')); ?>"
                                    title="<?php echo e(__('Certificate Template')); ?>"
                                ></iframe>
                            <?php endif; ?>

                        <div class="certificate-text recipient-name" id="nameElement"></div>
                        <div class="certificate-text certificate-number" id="numberElement"></div>
                        <div id="textBoxLayer"></div>
                        <div id="imageLayer"></div>
                            <div class="alignment-guides" id="alignmentGuides" aria-hidden="true">
                                <span class="alignment-guide alignment-guide-vertical" id="verticalGuide" hidden></span>
                                <span class="alignment-guide alignment-guide-horizontal" id="horizontalGuide" hidden></span>
                            </div>

                        </div>
                    </div>

                    <div class="preview-navigation">
                        <button type="button" class="nav-button" id="previousRecipient" aria-label="<?php echo e(__('Previous recipient')); ?>">
                            ← 
                        </button>

                        <strong id="pageIndicator">1 / <?php echo e(count($recipients)); ?></strong>

                        <button type="button" class="nav-button" id="nextRecipient" aria-label="<?php echo e(__('Next recipient')); ?>">
                            →
                        </button>
                    </div>

                </div>

                
                <aside class="editor-panel" aria-label="<?php echo e(__('Certificate element settings')); ?>">
                <div class="editor-panel-heading">
                    <div>
                        <span class="editor-eyebrow"><?php echo e(__('Design Workspace')); ?></span>
                        <h2><?php echo e(__('Element Editor')); ?></h2>
                        <p class="muted">
                            <?php echo e(__('Select an element on the certificate to edit it.')); ?>

                        </p>
                    </div>
                </div>

                <div class="editor-add-actions">
                    <button type="button" class="editor-add-card" id="addTextBox">
                        <span class="editor-add-icon">T</span>
                        <span class="editor-add-copy">
                            <strong><?php echo e(__('Add Text')); ?></strong>
                            <small><?php echo e(__('Add a new text element to the certificate.')); ?></small>
                        </span>
                        <span class="editor-add-plus">+</span>
                    </button>

                    <button type="button" class="editor-add-card" id="addImageButton">
                        <span class="editor-add-icon editor-add-icon-image">▧</span>
                        <span class="editor-add-copy">
                            <strong><?php echo e(__('Add Logo / Image')); ?></strong>
                            <small><?php echo e(__('PNG, JPG, or WebP · Max. 3 MB')); ?></small>
                        </span>
                        <span class="editor-add-plus">+</span>
                    </button>

                    <input
                        type="file"
                        id="imageUploadInput"
                        accept="image/png,image/jpeg,image/webp"
                        hidden
                    >
                </div>

                <div class="editor-elements">
                    <div class="editor-section-heading">
                        <h3><?php echo e(__('Elements')); ?></h3>

                        <p class="muted">
                            <?php echo e(__('Select a name, number, or object on the canvas.')); ?>

                        </p>
                    </div>

                    <div class="element-tabs">
                        <button
                            type="button"
                            class="element-tab"
                            data-element="name"
                        >
                            <span class="element-tab-symbol">T</span>
                            <span><?php echo e(__('Recipient Name')); ?></span>
                        </button>

                        <button
                            type="button"
                            class="element-tab"
                            data-element="number"
                        >
                            <span class="element-tab-symbol">#</span>
                            <span><?php echo e(__('Certificate Number')); ?></span>
                        </button>

                        <div class="text-box-tabs" id="textBoxTabs"></div>
                    </div>
                </div>

                <div class="editor-empty">
                    <div class="editor-empty-icon">↖</div>
                    <h3><?php echo e(__('No element selected')); ?></h3>

                    <p> <?php echo e(__('Select text or a logo in the preview to open its settings.')); ?> </p>
                </div>

                <div id="nameSettings" hidden>
                    <section class="setting-section">
                        <div class="editor-section-heading">
                            <div>
                                <span class="editor-eyebrow"><?php echo e(__('Text Content')); ?></span>
                                <h3><?php echo e(__('Recipient Name')); ?></h3>
                            </div>
                        </div>

                        <div class="field">
                            <label for="recipientNameInput">
                                <?php echo e(__('Recipient Name')); ?>

                            </label>

                            <input
                                type="text"
                                id="recipientNameInput"
                                maxlength="255"
                            >
                        </div>
                    </section>
                </div>

                <div id="numberSettingsPanel" hidden>
                    <section class="setting-section">
                        <div class="editor-section-heading">
                            <div>
                                <span class="editor-eyebrow"><?php echo e(__('Auto Generated')); ?></span>
                                <h3><?php echo e(__('Certificate Number')); ?></h3>
                            </div>
                        </div>

                        <div class="locked-value" id="numberValue"></div>

                        <p class="muted">
                            <?php echo e(__('The certificate number is generated automatically based on Step 3 settings.')); ?>

                        </p>
                    </section>
                </div>

                <div id="textBoxSettings" hidden>
                    <section class="setting-section">
                        <div class="editor-section-heading">
                            <div>
                                <span class="editor-eyebrow"><?php echo e(__('Text Element')); ?></span>
                                <h3><?php echo e(__('Text Content')); ?></h3>
                            </div>

                            <button
                                type="button"
                                class="editor-danger-button"
                                id="removeTextBox"
                            >
                                <?php echo e(__('Delete')); ?>

                            </button>
                        </div>

                        <div class="field">
                            <label for="textBoxContent"><?php echo e(__('Text Content')); ?></label>

                            <textarea
                                id="textBoxContent"
                                maxlength="1000"
                                rows="3"
                                placeholder="<?php echo e(__('Type something...')); ?>"
                            ></textarea>

                            <small>
                                <?php echo e(__('Maximum 1,000 characters. You can adjust the position directly in the preview.')); ?>

                            </small>
                        </div>

                        <label class="text-box-sync">
                            <input type="checkbox" id="syncTextBoxes">

                            <span>
                                <strong><?php echo e(__('Sync across all certificates')); ?></strong>

                                <small>
                                    <?php echo e(__('Use the same text and position for all recipients.')); ?>

                                </small>
                            </span>
                        </label>
                    </section>
                </div>

                <div id="imageSettingsPanel" hidden>
                    <section class="setting-section">
                        <div class="editor-section-heading">
                            <div>
                                <span class="editor-eyebrow"><?php echo e(__('Image Element')); ?></span>
                                <h3><?php echo e(__('Image Settings')); ?></h3>
                            </div>

                            <button
                                type="button"
                                class="editor-danger-button"
                                id="deleteImageButton"
                            >
                                <?php echo e(__('Delete')); ?>

                            </button>
                        </div>

                        <img
                            id="selectedImagePreview"
                            alt="<?php echo e(__('Selected image preview')); ?>"
                        >

                        <p class="muted">
                            <?php echo e(__('Drag the image on the canvas. Drag the corner handle to resize it.')); ?>

                        </p>

                        <div class="image-setting-actions">
                            <button
                                type="button"
                                class="action-button full-width"
                                id="replaceImageButton"
                            >
                                <?php echo e(__('Replace Image')); ?>

                            </button>
                        </div>
                    </section>
                </div>

                <div id="styleSettings" hidden>
                    <section class="setting-section">
                         <div class="editor-section-heading">
                            <div>
                                <span class="editor-eyebrow">
                                    <?php echo e(__('Appearance')); ?>

                                </span>

                                <h3><?php echo e(__('Text Appearance')); ?></h3>
                            </div>
                        </div>

                        <div class="field">
                            <label for="fontFamily">
                                <?php echo e(__('Font Family')); ?>

                            </label>

                            <select id="fontFamily">
                                <option value="Manrope">Manrope</option>
                                <option value="Poppins">Poppins</option>
                                <option value="Montserrat">Montserrat</option>
                                <option value="Lato">Lato</option>
                                <option value="Open Sans">Open Sans</option>
                                <option value="Roboto">Roboto</option>
                                <option value="Nunito">Nunito</option>
                                <option value="Raleway">Raleway</option>
                                <option value="Oswald">Oswald</option>
                                <option value="Playfair Display">Playfair Display</option>
                                <option value="Merriweather">Merriweather</option>
                                <option value="Lora">Lora</option>
                                <option value="Roboto Slab">Roboto Slab</option>
                                <option value="DM Sans">DM Sans</option>
                                <option value="Georgia">Georgia</option>
                                <option value="Arial">Arial</option>
                                <option value="Times New Roman">Times New Roman</option>
                            </select>
                        </div>

                        <div class="two-columns">
                            <div class="field">
                                <label for="fontSize">
                                    <?php echo e(__('Font Size')); ?>

                                </label>

                                <input
                                    type="number"
                                    id="fontSize"
                                >
                            </div>

                            <div class="field">
                                <label for="fontColor">
                                    <?php echo e(__('Color')); ?>

                                </label>

                                <input
                                    type="color"
                                    id="fontColor"
                                >
                            </div>
                        </div>

                        <div class="field">
                            <label><?php echo e(__('Text Style')); ?></label>
                            <div class="style-buttons">
                                <button
                                        type="button"
                                        class="style-toggle"
                                        id="boldButton"
                                        title="<?php echo e(__('Bold')); ?>"
                                        aria-label="<?php echo e(__('Bold')); ?>"
                                    >
                                    <svg viewBox="0 0 24 24"><path d="M7 5h6a4 4 0 0 1 0 8H7z"/><path d="M7 13h7a4 4 0 0 1 0 8H7z"/></svg>
                                </button>

                                <button
                                    type="button"
                                    class="style-toggle"
                                    id="italicButton"
                                    title="<?php echo e(__('Italic')); ?>"
                                    aria-label="<?php echo e(__('Italic')); ?>"
                                >
                                    <svg viewBox="0 0 24 24"><path d="M19 4H10M14 20H5M15 4 9 20"/></svg>
                                </button>

                                <button
                                    type="button"
                                    class="style-toggle"
                                    id="underlineButton"
                                    title="<?php echo e(__('Underline')); ?>"
                                    aria-label="<?php echo e(__('Underline')); ?>"
                                >
                                    <svg viewBox="0 0 24 24"><path d="M7 4v7a5 5 0 0 0 10 0V4"/><path d="M5 21h14"/></svg>
                                </button>
                            </div>
                        </div>

                        <div class="field">
                            <label><?php echo e(__('Text Alignment')); ?></label>
                            <div class="alignment-buttons">
                                <button
                                    type="button"
                                    data-align="left"
                                    title="<?php echo e(__('Align left')); ?>"
                                    aria-label="<?php echo e(__('Align left')); ?>"
                                >☰</button>

                                <button
                                    type="button"
                                    data-align="center"
                                    title="<?php echo e(__('Align center')); ?>"
                                    aria-label="<?php echo e(__('Align center')); ?>"
                                >≡</button>

                                <button
                                    type="button"
                                    data-align="right"
                                    title="<?php echo e(__('Align right')); ?>"
                                    aria-label="<?php echo e(__('Align right')); ?>"
                                >☷</button>
                            </div>
                        </div>

                        <div class="editor-position-fields">
                            <div class="field">
                                <label for="positionX">
                                    <?php echo e(__('Horizontal Position (%)')); ?>

                                </label>

                                <input
                                    type="number"
                                    id="positionX"
                                    min="0"
                                    max="100"
                                    step="0.1"
                                >
                            </div>

                            <div class="field">
                                <label for="positionY">
                                    <?php echo e(__('Vertical Position (%)')); ?>

                                </label>

                                <input
                                    type="number"
                                    id="positionY"
                                    min="0"
                                    max="100"
                                    step="0.1"
                                >
                            </div>
                        </div>

                        <button
                            type="button"
                            id="applyAllButton"
                        >
                            <?php echo e(__('Apply to All Certificates')); ?>

                        </button>
                    </section>
                </div>



    <div class="status-message" id="statusMessage" role="status" aria-live="polite"></div>
</aside>
            </section>

            <div class="editor-page-navigation">
<div class="editor-actions editor-navigation">
                    <a href="<?php echo e(route('certificate-number.index', ['back' => 1])); ?>"
                    class="action-button">
                        <span>←</span>
                        <?php echo e(__('Back')); ?>

                    </a>

                    <button type="button"
                            class="action-button primary-button"
                            id="saveButton">
                        <?php echo e(__('Continue')); ?>

                        <span>→</span>
                    </button>
                </div>
            </div>

            <form id="saveForm" method="POST" action="<?php echo e(route('certificate-edit.save')); ?>" hidden>
                <?php echo csrf_field(); ?>
            </form>
        </main>
    </div>

    <?php
        $editorMessages = [
            // General editor
            'text' => __('Text'),
            'limit' => __('You can add up to 50 text boxes.'),
            'newText' => __('Type text here'),

            // Image
            'imageAlt' => __('Certificate image'),
            'resizeImage' => __('Drag to resize'),
            'invalidImageFormat' => __('Image format must be PNG, JPG, or WebP.'),
            'imageTooLarge' => __('Maximum image size is 3 MB.'),
            'imageReadFailed' => __('Failed to read the image file. Please try again.'),
            'confirmDeleteImage' => __('Delete this image?'),

            // Apply settings
            'applied' => __('Settings applied to all certificates.'),
            'confirmApplyAll' => __('Apply this element settings to all certificates?'),
            'synced' => __('Text boxes synced across all certificates.'),
            'separate' => __('Text boxes can be edited separately for each certificate.'),

            // Save
            'saving' => __('Saving...'),
            'continue' => __('Continue'),
            'failed' => __('Failed to save changes.'),
            'saveSuccess' => __('Certificate changes saved successfully.'),
        ];

        $monthNames = [
            1 => __('January'),
            2 => __('February'),
            3 => __('March'),
            4 => __('April'),
            5 => __('May'),
            6 => __('June'),
            7 => __('July'),
            8 => __('August'),
            9 => __('September'),
            10 => __('October'),
            11 => __('November'),
            12 => __('December'),
        ];
    ?>

    <script>
        const recipients = <?php echo json_encode($recipients, 15, 512) ?>;
        const numberSettings = <?php echo json_encode($numberSettings, 15, 512) ?>;
        const rawSavedSettings = <?php echo json_encode($editSettings, 15, 512) ?>;
        const savedSettings = rawSavedSettings && typeof rawSavedSettings === 'object'
            && !Array.isArray(rawSavedSettings)
            ? rawSavedSettings
            : {};
        const editorMessages = <?php echo e(\Illuminate\Support\Js::from($editorMessages)); ?>;

        const romanMonths = {
            1: 'I', 2: 'II', 3: 'III', 4: 'IV',
            5: 'V', 6: 'VI', 7: 'VII', 8: 'VIII',
            9: 'IX', 10: 'X', 11: 'XI', 12: 'XII'
        };

        const defaultNameStyle = {
            font_family: 'Manrope',
            font_size: 24,
            color: '#4042A4',
            alignment: 'center',
            bold: true,
            italic: false,
            underline: false,
            x: 50,
            y: 50
        };

    const defaultNumberStyle = {
        ...defaultNameStyle,
        font_size: 14,
        bold: false,
        y: 70
    };

    const defaultTextBoxStyle = {
        ...defaultNameStyle,
        bold: false,
        y: 80
    };

    const defaultGlobalSettings = {
        name: { ...defaultNameStyle },
        number: { ...defaultNumberStyle },
        textBoxes: [],
        imageBoxes: []
    };

    const savedGlobalSettings = savedSettings.global;
    const normalizedGlobalSettings = savedGlobalSettings
        && typeof savedGlobalSettings === 'object'
        && !Array.isArray(savedGlobalSettings)
        ? savedGlobalSettings
        : {};

    const savedIndividualSettings = savedSettings.individual;
    const normalizedIndividualSettings = savedIndividualSettings
        && typeof savedIndividualSettings === 'object'
        && !Array.isArray(savedIndividualSettings)
        ? savedIndividualSettings
        : {};

    const settings = {
        global: {
            ...defaultGlobalSettings,
            ...normalizedGlobalSettings,
            name: {
                ...defaultNameStyle,
                ...(normalizedGlobalSettings.name && typeof normalizedGlobalSettings.name === 'object'
                    ? normalizedGlobalSettings.name
                    : {})
            },
            number: {
                ...defaultNumberStyle,
                ...(normalizedGlobalSettings.number && typeof normalizedGlobalSettings.number === 'object'
                    ? normalizedGlobalSettings.number
                    : {})
            },
            textBoxes: Array.isArray(normalizedGlobalSettings.textBoxes)
                ? normalizedGlobalSettings.textBoxes
                : [],
            imageBoxes: Array.isArray(normalizedGlobalSettings.imageBoxes)
                ? normalizedGlobalSettings.imageBoxes
                : []
        },
        individual: { ...normalizedIndividualSettings },
        syncTextBoxes: savedSettings.syncTextBoxes === true
    };
    settings.global.textBoxes = Array.isArray(settings.global.textBoxes)
        ? settings.global.textBoxes
        : [];
    settings.global.imageBoxes = Array.isArray(settings.global.imageBoxes)
        ? settings.global.imageBoxes
        : [];
    recipients.forEach((_, index) => {
        settings.individual[index] ??= {};
        if (!Array.isArray(settings.individual[index].textBoxes)) {
            settings.individual[index].textBoxes = JSON.parse(
                JSON.stringify(settings.global.textBoxes)
            );
        }
    });

        let currentIndex = 0;
        let selectedElement = null;
        let zoom = 1;

        let dragging = false;
        let dragPointerId = null;
        let dragStart = null;

        let isPanning = false;
        let panStartX = 0;
        let panStartY = 0;
        let scrollStartX = 0;
        let scrollStartY = 0;

        let undoStack = [];
        let redoStack = [];

    const nameElement = document.getElementById('nameElement');
    const numberElement = document.getElementById('numberElement');
    const stage = document.getElementById('certificateStage');
    const textBoxLayer = document.getElementById('textBoxLayer');
    const imageLayer = document.getElementById('imageLayer');
    const imageSettingsPanel = document.getElementById('imageSettingsPanel');
    const textBoxTabs = document.getElementById('textBoxTabs');
    const previewCanvas = document.getElementById('previewCanvas');
    const verticalGuide = document.getElementById('verticalGuide');
    const horizontalGuide = document.getElementById('horizontalGuide');
    const styleSettingsPanel = document.getElementById('styleSettings');

    const emptySelection = document.querySelector('.editor-empty');
    const applyAllButton = document.getElementById('applyAllButton');


        const fontFamily = document.getElementById('fontFamily');
        const fontSize = document.getElementById('fontSize');
        const fontColor = document.getElementById('fontColor');

    const positionX = document.getElementById('positionX');
    const positionY = document.getElementById('positionY');

    function getTextBoxes(index = currentIndex) {
        return settings.syncTextBoxes
            ? settings.global.textBoxes
            : (settings.individual[index]?.textBoxes ?? []);
    }

    function setCurrentTextBoxes(textBoxes) {
        if (settings.syncTextBoxes) {
            settings.global.textBoxes = textBoxes;
            return;
        }

        settings.individual[currentIndex] ??= {};
        settings.individual[currentIndex].textBoxes = textBoxes;
    }

        // NOMOR SERTIFIKAT
        function buildNumber() {
            const fields = Array.isArray(numberSettings.fields) ? numberSettings.fields : [];
            const month = Number(numberSettings.month);
            const sequenceNumber = Number(numberSettings.start_number || 1) + currentIndex;

            const monthNames = <?php echo e(Illuminate\Support\Js::from($monthNames)); ?>;

            // Step 4 hanya merender bagian yang benar-benar dibuat di Step 3.
            // Tidak ada lagi format default/hardcoded universitas.
            if (fields.length === 0) return '';

            const values = fields.map(field => {
                switch (field.type) {
                    case 'number':
                        return String(sequenceNumber).padStart(3, '0');
                    case 'month':
                        return String(month);
                    case 'roman_month':
                        return romanMonths[month] || '';
                    case 'month_name':
                        return monthNames[month] || '';
                    case 'year':
                        return String(numberSettings.year || '');
                    case 'text':
                    default:
                        return String(field.value ?? '');
                }
            });

            return values.join(numberSettings.separator || '/');
        }

    // STYLE ELEMENT
    function getStyle(element) {
        const textBox = getTextBoxes().find(item => item.id === element);
        const style = textBox
            ?? settings.individual[currentIndex]?.[element]
            ?? settings.global[element];

            return {
                ...style,
                bold: style.bold === true || style.bold === 1 || style.bold === '1' || style.bold === 'true',
                italic: style.italic === true || style.italic === 1 || style.italic === '1' || style.italic === 'true',
                underline: style.underline === true || style.underline === 1 || style.underline === '1' || style.underline === 'true'
            };
        }

    function setStyle(element, style) {
        const textBox = getTextBoxes().find(item => item.id === element);

        if (textBox) {
            Object.assign(textBox, style);

            return;
        }

        if (!settings.individual[currentIndex]) {
            settings.individual[currentIndex] = {};
        }

        settings.individual[currentIndex][element] = { ...style };
    }

    function renderElement(element, style, content) {
        element.textContent = content;

        element.style.left = style.x + '%';
        element.style.top = style.y + '%';
        element.style.fontFamily = `"${style.font_family}", sans-serif`;
        element.style.fontSize = style.font_size + 'px';
        element.style.color = style.color;
        element.style.fontWeight = style.bold ? '700' : '400';
        element.style.fontStyle = style.italic ? 'italic' : 'normal';
        element.style.textDecoration = style.underline ? 'underline' : 'none';
        element.style.textAlign = style.alignment;
        element.style.fontSynthesis = 'style';
    }

    function renderTextBoxes() {
        const textBoxes = getTextBoxes();
        const textBoxIds = textBoxes.map(textBox => textBox.id);

        [...textBoxLayer.children].forEach(element => {
            if (!textBoxIds.includes(element.dataset.textBoxId)) {
                element.remove();
            }
        });
        [...textBoxTabs.children].forEach(button => button.remove());

        textBoxes.forEach((textBox, index) => {
            let element = [...textBoxLayer.children].find(
                child => child.dataset.textBoxId === textBox.id
            );

            if (!element) {
                element = document.createElement('div');
                element.className = 'certificate-text';
                element.dataset.textBoxId = textBox.id;
                element.dataset.elementKey = textBox.id;
                element.addEventListener('click', () => {
                    selectedElement = textBox.id;
                    render();
                });
                element.addEventListener('pointerdown', startDrag);
                element.addEventListener('pointermove', moveDrag);
                element.addEventListener('pointerup', endDrag);
                element.addEventListener('pointercancel', endDrag);
                textBoxLayer.append(element);
            }

            renderElement(element, getStyle(textBox.id), textBox.content);
            element.classList.toggle('selected', selectedElement === textBox.id);

            const tab = document.createElement('button');
            tab.type = 'button';
            tab.className = 'element-tab';
            tab.dataset.textBoxId = textBox.id;
            tab.textContent = `${editorMessages.text} ${index + 1}`;
            tab.classList.toggle('active', selectedElement === textBox.id);
            tab.addEventListener('click', () => {
                selectedElement = textBox.id;
                selectedImageId = null;
                render();
            });
            textBoxTabs.append(tab);
        });
    }

    // IMAGE / LOGO ELEMENTS (stored as data URLs in settings.global.imageBoxes)
    let selectedImageId = null;
    let imageDragState = null;

    function renderImageBoxes() {
        const boxes = settings.global.imageBoxes;
        const validIds = boxes.map(box => box.id);
        [...imageLayer.children].forEach(node => {
            if (!validIds.includes(node.dataset.imageBoxId)) node.remove();
        });
        boxes.forEach(box => {
            let wrapper = [...imageLayer.children].find(node => node.dataset.imageBoxId === box.id);
            if (!wrapper) {
                wrapper = document.createElement('div');
                wrapper.className = 'image-box-wrapper';
                wrapper.dataset.imageBoxId = box.id;
                const img = document.createElement('img');
                img.alt = box.name || editorMessages.imageAlt;
                const handle = document.createElement('span');
                handle.className = 'image-resize-handle';
                handle.title = editorMessages.resizeImage;
                handle.setAttribute('aria-label', editorMessages.resizeImage);
                wrapper.append(img, handle);
                wrapper.addEventListener('pointerdown', startImageInteraction);
                wrapper.addEventListener('pointermove', moveImageInteraction);
                wrapper.addEventListener('pointerup', endImageInteraction);
                wrapper.addEventListener('pointercancel', endImageInteraction);
                imageLayer.append(wrapper);
            }
            const img = wrapper.querySelector('img');
            if (img.src !== box.src) img.src = box.src;
            wrapper.style.left = `${box.x}%`;
            wrapper.style.top = `${box.y}%`;
            wrapper.style.width = `${box.width}%`;
            wrapper.style.height = `${box.height}%`;
            wrapper.classList.toggle('selected', selectedImageId === box.id);
        });
    }
    function updateImagePanel() {
        const image = settings.global.imageBoxes.find(
            box => box.id === selectedImageId
        );

        imageSettingsPanel.hidden = !image;
        imageSettingsPanel.classList.toggle('active', Boolean(image));

        if (!image) {
            return;
        }

        const preview = document.getElementById('selectedImagePreview');

        preview.src = image.src;
        preview.alt = image.name || editorMessages.imageAlt;
    }

    function startImageInteraction(event) {
        if (event.button !== 0) return;
        const wrapper = event.currentTarget;
        const boxId = wrapper.dataset.imageBoxId;
        const box = settings.global.imageBoxes.find(item => item.id === boxId);
        if (!box) return;
        saveHistory();
        selectedImageId = boxId;
        selectedElement = null;
        const stageRect = stage.getBoundingClientRect();
        const isResize = event.target.classList.contains('image-resize-handle');
        imageDragState = {
            pointerId: event.pointerId,
            mode: isResize ? 'resize' : 'move',
            startX: event.clientX,
            startY: event.clientY,
            originalX: box.x,
            originalY: box.y,
            originalWidth: box.width,
            originalHeight: box.height,
            stageWidth: stageRect.width,
            stageHeight: stageRect.height
        };
        wrapper.setPointerCapture(event.pointerId);
        event.stopPropagation();
        render();
        event.preventDefault();
    }

    function moveImageInteraction(event) {
        if (!imageDragState || event.pointerId !== imageDragState.pointerId) return;
        const box = settings.global.imageBoxes.find(item => item.id === selectedImageId);
        if (!box) return;
        const dx = event.clientX - imageDragState.startX;
        const dy = event.clientY - imageDragState.startY;
        const dxPct = dx / imageDragState.stageWidth * 100;
        const dyPct = dy / imageDragState.stageHeight * 100;
        if (imageDragState.mode === 'move') {
            const nextX = Math.max(0, Math.min(100 - box.width, imageDragState.originalX + dxPct));
            const nextY = Math.max(0, Math.min(100 - box.height, imageDragState.originalY + dyPct));
            const snapped = snapToStageCenter(nextX, nextY, box.width, box.height, true);
            box.x = snapped.x;
            box.y = snapped.y;
        } else {
            clearAlignmentGuides();
            box.width = Math.max(2, Math.min(100 - box.x, imageDragState.originalWidth + dxPct));
            box.height = Math.max(2, Math.min(100 - box.y, imageDragState.originalHeight + dyPct));
        }
        renderImageBoxes();
    }

    function endImageInteraction(event) {
        if (!imageDragState || event.pointerId !== imageDragState.pointerId) return;
        imageDragState = null;
        clearAlignmentGuides();
    }

    function loadImageFile(file) {
        if (!file) return;

        if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) {
            alert(editorMessages.invalidImageFormat);
            return;
        }

        if (file.size > 3 * 1024 * 1024) {
            alert(editorMessages.imageTooLarge);
            return;
        }

        const reader = new FileReader();

        reader.onload = () => {
            saveHistory();

            const box = {
                id: `image-${crypto.randomUUID()}`,
                name: file.name,
                src: reader.result,
                x: 8,
                y: 8,
                width: 16,
                height: 16
            };

            settings.global.imageBoxes.push(box);
            selectedImageId = box.id;
            selectedElement = null;

            render();
        };

        reader.onerror = () => {
            alert(editorMessages.imageReadFailed);
        };

        reader.readAsDataURL(file);
    }

    document.getElementById('addImageButton').addEventListener('click', () => {
        document.getElementById('imageUploadInput').click();
    });
    document.getElementById('imageUploadInput').addEventListener('change', event => {
        const input = event.target;
        const file = input.files[0];
        const replaceId = input.dataset.replaceId;
        input.dataset.replaceId = '';

        if (!file) return;
        if (!replaceId) {
            loadImageFile(file);
            input.value = '';
            return;
        }

        if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) {
            alert(editorMessages.invalidImageFormat);
            input.value = '';
            return;
        }

        if (file.size > 3 * 1024 * 1024) {
            alert(editorMessages.imageTooLarge);
            input.value = '';
            return;
        }

        const reader = new FileReader();
        reader.onload = () => {
            saveHistory();
            const box = settings.global.imageBoxes.find(item => item.id === replaceId);
            if (box) { box.src = reader.result; box.name = file.name; }
            render();
        };

        reader.onerror = () => {
            alert(editorMessages.imageReadFailed);
        };

        reader.readAsDataURL(file);
        input.value = '';
    });
    document.getElementById('deleteImageButton').addEventListener('click', () => {
        if (!selectedImageId) return;
        saveHistory();
        settings.global.imageBoxes = settings.global.imageBoxes.filter(box => box.id !== selectedImageId);
        selectedImageId = null;
        render();
    });

        // UNDO / REDO
        function createSnapshot() {
            return JSON.stringify({
                recipients,
                settings,
                currentIndex,
                selectedElement,
                selectedImageId
            });
        }

        function updateHistoryButtons() {
            document.getElementById('undoButton').disabled = undoStack.length === 0;
            document.getElementById('redoButton').disabled = redoStack.length === 0;
        }

        function saveHistory() {
            undoStack.push(createSnapshot());

            if (undoStack.length > 100) {
                undoStack.shift();
            } redoStack = [];
            updateHistoryButtons();
        }

        function restoreSnapshot(snapshot) {
            const data = JSON.parse(snapshot);

            recipients.splice(0, recipients.length, ...data.recipients);

        settings.global = data.settings.global;
        settings.individual = data.settings.individual;
        settings.syncTextBoxes = data.settings.syncTextBoxes;

            currentIndex = data.currentIndex;
            selectedElement = data.selectedElement;
            selectedImageId = data.selectedImageId ?? null;

            render();
            updateHistoryButtons();
        }

        document.getElementById('undoButton').addEventListener('click', () => {
            if (undoStack.length === 0) return;

            redoStack.push(createSnapshot());
            restoreSnapshot(undoStack.pop());
        });

        document.getElementById('redoButton').addEventListener('click', () => {
            if (redoStack.length === 0) return;

            undoStack.push(createSnapshot());
            restoreSnapshot(redoStack.pop());
        });

    // RENDER PREVIEW
    function render() {
        const recipient = recipients[currentIndex];
        const textBoxes = getTextBoxes();

        if (
            typeof selectedElement === 'string'
            && selectedElement.startsWith('text-')
            && !textBoxes.some(textBox => textBox.id === selectedElement)
        ) {
            selectedElement = 'name';
        }

            document.getElementById('recipientNameInput').value = recipient.name;

            const certificateNumber = buildNumber();

            document.getElementById('numberValue').textContent =
                certificateNumber;

            renderElement(
                numberElement,
                getStyle('number'),
                certificateNumber
            );

        renderElement(nameElement, getStyle('name'), recipient.name);
       
        renderTextBoxes();
        renderImageBoxes();
        updateImagePanel();

        nameElement.classList.toggle('selected', selectedElement === 'name');
        numberElement.classList.toggle('selected', selectedElement === 'number');
        const selectedTextBox = textBoxes.find(
            textBox => textBox.id === selectedElement
        );
        document.getElementById('textBoxContent').value = selectedTextBox?.content ?? '';
        document.getElementById('addTextBox').disabled =
            textBoxes.length >= 50;
        document.getElementById('syncTextBoxes').checked = settings.syncTextBoxes;

            document.getElementById('pageIndicator').textContent =
                `${currentIndex + 1} / ${recipients.length}`;

            document.getElementById('previousRecipient').disabled = currentIndex === 0;
            document.getElementById('nextRecipient').disabled =
                currentIndex === recipients.length - 1;

            const hasSelection = selectedElement !== null;

            document.getElementById('nameSettings').hidden =
                !hasSelection || selectedElement !== 'name';

            document.getElementById('numberSettingsPanel').hidden =
                !hasSelection || selectedElement !== 'number';

        document.getElementById('textBoxSettings').hidden =
            !selectedTextBox;

        document.getElementById('styleSettings').hidden =
            !hasSelection || selectedElement === 'number';

        emptySelection.hidden = hasSelection || Boolean(selectedImageId);

            document.querySelectorAll('.element-tab').forEach(button => {
                button.classList.toggle(
                    'active',
                    button.dataset.element === selectedElement
                );
            });

        applyAllButton.disabled = !hasSelection || Boolean(selectedTextBox);
            if (hasSelection) {
                updateControls();
            }
        }

        // PANEL PENGATURAN
        function updateControls() {
            const style = getStyle(selectedElement);

            fontFamily.value = style.font_family;
            fontSize.value = style.font_size;
            fontColor.value = style.color;

            if (positionX) positionX.value = Number(style.x.toFixed(1));
            if (positionY) positionY.value = Number(style.y.toFixed(1));

            document.getElementById('boldButton')
                .classList.toggle('active', style.bold);

            document.getElementById('italicButton')
                .classList.toggle('active', style.italic);

            document.getElementById('underlineButton')
                .classList.toggle('active', style.underline);

            document.querySelectorAll('[data-align]').forEach(button => {
                button.classList.toggle(
                    'active',
                    button.dataset.align === style.alignment
                );
            });
        }

        function updateCurrentStyle(field, value) {
            if (!selectedElement) return;
            saveHistory();

            const style = { ...getStyle(selectedElement) };
            style[field] = value;

            setStyle(selectedElement, style);
            render();
        }

        // PILIH ELEMENT
        document.querySelectorAll('.element-tab').forEach(button => {
            button.addEventListener('click', () => {
                selectedElement = button.dataset.element;
                selectedImageId = null;
                render();
            });
        });

        nameElement.addEventListener('click', () => {
            selectedElement = 'name';
            render();
        });

    numberElement.addEventListener('click', () => {
        selectedElement = 'number';
        render();
    });

    document.getElementById('addTextBox').addEventListener('click', () => {
        const textBoxes = getTextBoxes();

        if (textBoxes.length >= 50) {
            document.getElementById('statusMessage').textContent =
                editorMessages.limit;

            return;
        }

        saveHistory();

        const textBox = {
            ...defaultTextBoxStyle,
            id: `text-${crypto.randomUUID()}`,
            content: editorMessages.newText
        };
        textBoxes.push(textBox);
        setCurrentTextBoxes(textBoxes);
        selectedElement = textBox.id;
        selectedImageId = null;
        render();
        document.getElementById('textBoxContent').focus();
        document.getElementById('textBoxContent').select();
    });

    document.getElementById('removeTextBox').addEventListener('click', () => {
        const textBoxes = getTextBoxes();
        const textBoxIndex = textBoxes.findIndex(
            textBox => textBox.id === selectedElement
        );

        if (textBoxIndex === -1) return;

        saveHistory();
        textBoxes.splice(textBoxIndex, 1);
        setCurrentTextBoxes(textBoxes);

        selectedElement = 'name';
        render();
    });

        previewCanvas.addEventListener('click', event => {
            const clickedEmptyArea =
                event.target === previewCanvas ||
                event.target === stage ||
                event.target.id === 'templateImage';

            if (clickedEmptyArea && selectedElement !== null) {
                selectedElement = null;
                render();
            }
        });

        // EDIT NAMA PENERIMA
        let recipientInputHistorySaved = false;
        const recipientNameInput = document.getElementById('recipientNameInput');

        recipientNameInput.addEventListener('focus', () => {
            recipientInputHistorySaved = false;
        });

        recipientNameInput.addEventListener('input', event => {
            if (!recipientInputHistorySaved) {
                saveHistory();
                recipientInputHistorySaved = true;
            }

            recipients[currentIndex].name = event.target.value;
            nameElement.textContent = event.target.value;
        });

        recipientNameInput.addEventListener('blur', () => {
            recipientInputHistorySaved = false;
        });

    document.getElementById('textBoxContent').addEventListener('input', event => {
        const textBoxes = getTextBoxes();
        const textBox = textBoxes.find(
            item => item.id === selectedElement
        );

        if (!textBox) return;

        saveHistory();
        textBox.content = event.target.value;
        setCurrentTextBoxes(textBoxes);
        const element = [...textBoxLayer.children].find(
            child => child.dataset.textBoxId === textBox.id
        );
        if (element) element.textContent = event.target.value;
    });


        // FONT, WARNA, DAN STYLE
        fontFamily.addEventListener('change', event => {
            updateCurrentStyle('font_family', event.target.value);
        });

        fontSize.addEventListener('change', event => {
            const value = Math.max(8, Math.min(150, Number(event.target.value)));
            updateCurrentStyle('font_size', value);
        });

        fontColor.addEventListener('change', event => {
            updateCurrentStyle('color', event.target.value);
        });

        [positionX, positionY].forEach((input, index) => {
            if (!input) return;
            input.addEventListener('change', event => {
                const value = Math.max(0, Math.min(100, Number(event.target.value)));
                updateCurrentStyle(index === 0 ? 'x' : 'y', value);
            });
        });

        document.getElementById('boldButton').addEventListener('click', () => {
            if (!selectedElement) return;
            updateCurrentStyle('bold', !getStyle(selectedElement).bold);
        });

        document.getElementById('italicButton').addEventListener('click', () => {
            if (!selectedElement) return;
            updateCurrentStyle('italic', !getStyle(selectedElement).italic);
        });

        document.getElementById('underlineButton').addEventListener('click', () => {
            if (!selectedElement) return;
            updateCurrentStyle('underline', !getStyle(selectedElement).underline);
        });

        document.querySelectorAll('[data-align]').forEach(button => {
            button.addEventListener('click', () => {
                updateCurrentStyle('alignment', button.dataset.align);
            });
        });

        // SMART ALIGNMENT GUIDES — snap text to the certificate center.
        function updateAlignmentGuides(showVertical, showHorizontal) {
            if (verticalGuide) verticalGuide.hidden = !showVertical;
            if (horizontalGuide) horizontalGuide.hidden = !showHorizontal;
        }

        function snapToStageCenter(x, y, width = 0, height = 0, useTopLeft = false) {
            const threshold = 0.9;
            let showVertical = false;
            let showHorizontal = false;
            const centerX = useTopLeft ? x + width / 2 : x;
            const centerY = useTopLeft ? y + height / 2 : y;

            if (Math.abs(centerX - 50) <= threshold) {
                x = useTopLeft ? 50 - width / 2 : 50;
                showVertical = true;
            }
            if (Math.abs(centerY - 50) <= threshold) {
                y = useTopLeft ? 50 - height / 2 : 50;
                showHorizontal = true;
            }
            updateAlignmentGuides(showVertical, showHorizontal);
            return { x, y };
        }

        function clearAlignmentGuides() {
            updateAlignmentGuides(false, false);
        }

        // DRAG NAMA DAN NOMOR
        function startDrag(event) {
            if (event.button !== 0) return;

            saveHistory();
            const element = event.currentTarget;

        selectedElement = element.dataset.elementKey;
        selectedImageId = null;
        render();

            dragging = true;
            dragPointerId = event.pointerId;

            const rect = stage.getBoundingClientRect();
            const style = getStyle(selectedElement);

            dragStart = {
                pointerX: event.clientX,
                pointerY: event.clientY,
                x: style.x,
                y: style.y,
                width: rect.width,
                height: rect.height
            };

            element.setPointerCapture(event.pointerId);
            event.preventDefault();
        }

        function moveDrag(event) {
            if (!dragging || event.pointerId !== dragPointerId) return;

            const dx = (event.clientX - dragStart.pointerX) / dragStart.width * 100;
            const dy = (event.clientY - dragStart.pointerY) / dragStart.height * 100;

            let nextX = Math.max(0, Math.min(100, dragStart.x + dx));
            let nextY = Math.max(0, Math.min(100, dragStart.y + dy));
            const snapped = snapToStageCenter(nextX, nextY);

            const style = {
                ...getStyle(selectedElement),
                x: snapped.x,
                y: snapped.y
            };

            setStyle(selectedElement, style);
            render();
        }

    function endDrag(event) {
        if (!dragging || event.pointerId !== dragPointerId) return;

        dragging = false;
        dragPointerId = null;
        clearAlignmentGuides();
    }

    nameElement.dataset.elementKey = 'name';
    numberElement.dataset.elementKey = 'number';

        [nameElement, numberElement].forEach(element => {
            element.addEventListener('pointerdown', startDrag);
            element.addEventListener('pointermove', moveDrag);
            element.addEventListener('pointerup', endDrag);
            element.addEventListener('pointercancel', endDrag);
        });


        // NAVIGASI SERTIFIKAT
        document.getElementById('previousRecipient').addEventListener('click', () => {
            if (currentIndex > 0) {
                currentIndex--;
                render();
            }
        });

        document.getElementById('nextRecipient').addEventListener('click', () => {
            if (currentIndex < recipients.length - 1) {
                currentIndex++;
                render();
            }
        });

        // ZOOM
        function updateZoom() {
            const width = 100 * zoom;

            stage.style.width = width + '%';
            stage.style.flexBasis = width + '%';

            previewCanvas.style.justifyContent = 'flex-start';
            previewCanvas.style.alignItems = 'flex-start';

            document.getElementById('zoomLabel').textContent =
                Math.round(zoom * 100) + '%';
        }

        document.getElementById('zoomIn').addEventListener('click', () => {
            zoom = Math.min(3, Math.round((zoom + 0.1) * 10) / 10);
            updateZoom();
        });

        document.getElementById('zoomOut').addEventListener('click', () => {
            zoom = Math.max(0.5, Math.round((zoom - 0.1) * 10) / 10);
            updateZoom();
        });


        // GESER AREA PREVIEW
        previewCanvas.addEventListener('pointerdown', event => {
            if (event.target.closest('.certificate-text')) return;
            if (event.button !== 0) return;

            isPanning = true;

            panStartX = event.clientX;
            panStartY = event.clientY;

            scrollStartX = previewCanvas.scrollLeft;
            scrollStartY = previewCanvas.scrollTop;

            previewCanvas.classList.add('is-panning');
            previewCanvas.setPointerCapture(event.pointerId);

            event.preventDefault();
        });

        previewCanvas.addEventListener('pointermove', event => {
            if (!isPanning) return;
            const dx = event.clientX - panStartX;
            const dy = event.clientY - panStartY;
            previewCanvas.scrollLeft = scrollStartX - dx;
            previewCanvas.scrollTop = scrollStartY - dy;
        });

        function stopPanning() {
            isPanning = false;
            previewCanvas.classList.remove('is-panning');
        }

        previewCanvas.addEventListener('pointerup', stopPanning);
        previewCanvas.addEventListener('pointercancel', stopPanning);

        // APPLY ALL
        applyAllButton.addEventListener('click', () => {
            if (!selectedElement) return;

            const confirmation = confirm(editorMessages.confirmApplyAll);
            if (!confirmation) return;

            saveHistory();

            const style = { ...getStyle(selectedElement) };

            settings.global[selectedElement] = style;

            Object.keys(settings.individual).forEach(index => {
                if (settings.individual[index]) {
                    delete settings.individual[index][selectedElement];

                    if (Object.keys(settings.individual[index]).length === 0) {
                        delete settings.individual[index];
                    }
                }
            });

            render();

        document.getElementById('statusMessage').textContent =
            editorMessages.applied;
    });

    document.getElementById('syncTextBoxes').addEventListener('change', event => {
        saveHistory();
        const currentTextBoxes = JSON.parse(
            JSON.stringify(getTextBoxes(currentIndex))
        );
        settings.syncTextBoxes = event.target.checked;

        if (settings.syncTextBoxes) {
            settings.global.textBoxes = currentTextBoxes;
        } else {
            recipients.forEach((recipient, index) => {
                settings.individual[index] ??= {};
                settings.individual[index].textBoxes = JSON.parse(
                    JSON.stringify(settings.global.textBoxes)
                );
            });
            settings.global.textBoxes = [];
        }

        render();
        document.getElementById('statusMessage').textContent =
            settings.syncTextBoxes
                ? editorMessages.synced
                : editorMessages.separate;
    });


        // SIMPAN PERUBAHAN
        document.getElementById('saveButton').addEventListener('click', async () => {
            const button = document.getElementById('saveButton');
            if (button.disabled) {
                return;
            }
            const status = document.getElementById('statusMessage');

            button.disabled = true;
            button.textContent = editorMessages.saving;
            status.textContent = '';

        const payload = {
            recipients,
            settings: {
                global: {
                    name: settings.global.name,
                    number: settings.global.number,
                    textBoxes: settings.global.textBoxes,
                    imageBoxes: settings.global.imageBoxes
                },
                individual: settings.individual,
                syncTextBoxes: settings.syncTextBoxes
            }
        };

            try {
                const response = await fetch(
                    '<?php echo e(route('certificate-edit.save')); ?>',
                    {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Accept': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector(
                                'meta[name="csrf-token"]'
                            ).content
                        },
                        body: JSON.stringify(payload)
                    }
                );

            if (!response.ok) {
                const result = await response.json().catch(() => ({}));
                const validationErrors = Object.values(result.errors ?? {}).flat();
                const message = validationErrors.length > 0
                    ? validationErrors.join(' ')
                    : (result.message || editorMessages.failed);

                throw new Error(message);
            }

                window.location.href = "<?php echo e(route('certificate-review.index')); ?>";
            } catch (error) {
                status.textContent = error.message;
            } finally {
                button.disabled = false;
                button.textContent = `${editorMessages.continue} →`;
            } 
        });

        // MULAI EDITOR
        render();
        updateHistoryButtons();

    </script>
</body>
</html><?php /**PATH C:\Users\Sora\Documents\Certificate Project\Certificate\resources\views/certificate/step4.blade.php ENDPATH**/ ?>