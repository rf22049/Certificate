<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(__('Recipient Data')); ?> | ProCert</title>
    <?php echo $__env->make('partials.favicon', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <?php echo $__env->make('partials.theme-init', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>
    <div class="app-shell">
        <?php echo $__env->make('partials.wizard-header', ['currentStep' => 2], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <main class="recipient-page">
            <div class="recipient-heading">
                <div>
                    <h1><?php echo e(__('Enter Recipient Data')); ?></h1>
                    <p><?php echo e(__('Add the names of certificate recipients')); ?></p>
                </div>

                <nav class="recipient-mode" aria-label="<?php echo e(__('Recipient input method')); ?>">
                    <a class="recipient-mode-button <?php echo e($mode === 'import' ? 'is-selected' : ''); ?>" href="<?php echo e(route('recipients.index', ['mode' => 'import'])); ?>" <?php if($mode === 'import'): ?> aria-current="page" <?php endif; ?>>
                        <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <rect x="3" y="3.5" width="14" height="13" rx="1" />
                            <path d="M3 8h14M8 3.5v13" />
                        </svg>
                        <?php echo e(__('Upload Excel / CSV')); ?>

                    </a>

                    <a class="recipient-mode-button <?php echo e($mode === 'manual' ? 'is-selected' : ''); ?>" href="<?php echo e(route('recipients.index', ['mode' => 'manual'])); ?>" <?php if($mode === 'manual'): ?> aria-current="page" <?php endif; ?>>
                        <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <path d="M11.5 4H4.25A1.25 1.25 0 0 0 3 5.25v10.5A1.25 1.25 0 0 0 4.25 17h10.5A1.25 1.25 0 0 0 16 15.75V9" />
                            <path d="m9 11 1-.2 6.3-6.3a1.4 1.4 0 0 0-2-2L8 9l-1 3 2-.4Z" />
                        </svg>
                        <?php echo e(__('Enter Manually')); ?>

                    </a>
                </nav>
            </div>

            <?php if(session('status')): ?>
                <p class="recipient-status" role="status"><?php echo e(session('status')); ?></p>
            <?php endif; ?>

            <section class="recipient-workspace recipient-workspace--manual" data-recipient-panel="manual" <?php if($mode !== 'manual'): ?> hidden <?php endif; ?>>
                <form class="recipient-manual-form" method="POST"
                    action="<?php echo e(route('recipients.store')); ?>" data-manual-form>
                   
                    <?php echo csrf_field(); ?>
                    <?php ($manualRecipients = old('recipients', $recipients)); ?>

                    <div class="recipient-table-toolbar">
                        <button class="outline-action" type="button" data-add-recipient>
                            <svg viewBox="0 0 20 20" fill="none" stroke="currentColor"
                                stroke-width="2" stroke-linecap="round" aria-hidden="true">
                                <path d="M10 3v14M3 10h14" />
                            </svg>
                            <?php echo e(__('Add Row')); ?>

                        </button>
                    </div>

                    <div class="recipient-table-wrap">
                        <?php $__errorArgs = ['recipients'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="form-error recipient-error" role="alert">
                                <?php echo e($message); ?>

                            </p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <table class="recipient-table recipient-table--manual">
                            <thead>
                                <tr>
                                    <th scope="col"><?php echo e(__('No.')); ?></th>
                                    <th scope="col"><?php echo e(__('Recipient Name')); ?></th>
                                    <th scope="col"><?php echo e(__('Note')); ?></th>
                                </tr>
                            </thead>

                            <tbody data-manual-rows>
                                <?php $__empty_1 = true; $__currentLoopData = $manualRecipients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $recipient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr data-recipient-row>
                                        <td class="recipient-number">
                                            <span data-row-number><?php echo e($index + 1); ?></span>
                                        </td>

                                        <td>
                                            <input
                                                name="recipients[<?php echo e($index); ?>][name]"
                                                value="<?php echo e($recipient['name'] ?? ''); ?>"
                                                maxlength="255"
                                                aria-label="<?php echo e(__('Recipient name, row :number', ['number' => $index + 1])); ?>"
                                                data-recipient-name
                                            >
                                        </td>

                                        <td>
                                            <div class="recipient-note-cell">
                                                <input
                                                    name="recipients[<?php echo e($index); ?>][note]"
                                                    value="<?php echo e($recipient['note'] ?? ''); ?>"
                                                    maxlength="255"
                                                    aria-label="<?php echo e(__('Note, row :number', ['number' => $index + 1])); ?>"
                                                    data-recipient-note
                                                >

                                                <button class="delete-row-button"
                                                    type="button"
                                                    data-delete-row
                                                    aria-label="<?php echo e(__('Delete row :number', ['number' => $index + 1])); ?>"
                                                    title="<?php echo e(__('Delete row')); ?>">
                                                    <svg viewBox="0 0 20 20" fill="none"
                                                        stroke="currentColor" stroke-width="1.8"
                                                        stroke-linecap="round"
                                                        stroke-linejoin="round"
                                                        aria-hidden="true">
                                                        <path d="M3 5h14M7 5V3h6v2m-8 0 1 12h8l1-12M8 8v6m4-6v6"/>
                                                    </svg>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr data-recipient-row>
                                        <td class="recipient-number">
                                            <span data-row-number>1</span>
                                        </td>

                                        <td>
                                            <input name="recipients[0][name]"
                                                maxlength="255"
                                                aria-label="<?php echo e(__('Recipient name, row :number', ['number' => 1])); ?>"
                                                data-recipient-name>
                                        </td>

                                        <td>
                                            <div class="recipient-note-cell">
                                                <input name="recipients[0][note]"
                                                    maxlength="255"
                                                    aria-label="<?php echo e(__('Note, row :number', ['number' => 1])); ?>"
                                                    data-recipient-note>

                                                <button class="delete-row-button"
                                                    type="button"
                                                    data-delete-row
                                                    aria-label="<?php echo e(__('Delete row :number', ['number' => 1])); ?>"
                                                    title="<?php echo e(__('Delete row')); ?>">
                                                    <svg viewBox="0 0 20 20" fill="none"
                                                        stroke="currentColor" stroke-width="1.8"
                                                        stroke-linecap="round"
                                                        stroke-linejoin="round"
                                                        aria-hidden="true">
                                                        <path d="M3 5h14M7 5V3h6v2m-8 0 1 12h8l1-12M8 8v6m4-6v6"/>
                                                    </svg>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="recipient-form-footer">
                        <a class="secondary-button" href="<?php echo e(route('home')); ?>">
                            <svg viewBox="0 0 24 24" fill="none"
                                stroke="currentColor" stroke-width="2"
                                stroke-linecap="round" stroke-linejoin="round"
                                aria-hidden="true">
                                <path d="M19 12H5M12 19l-7-7 7-7"/>
                            </svg>
                            <?php echo e(__('Back')); ?>

                        </a>

                        <button class="primary-button" type="submit">
                            <?php echo e(__('Continue')); ?>

                            <svg viewBox="0 0 24 24" fill="none"
                                stroke="currentColor" stroke-width="2"
                                stroke-linecap="round" stroke-linejoin="round"
                                aria-hidden="true">
                                <path d="M5 12h14M13 6l6 6-6 6" />
                            </svg>
                        </button>
                    </div>
                </form>
            </section>

            <section class="recipient-workspace recipient-workspace--import" data-recipient-panel="import" <?php if($mode !== 'import'): ?> hidden <?php endif; ?>>
                <form class="recipient-import-form" method="POST" action="<?php echo e(route('recipients.import')); ?>" enctype="multipart/form-data" data-recipient-import-form>
                    
                <?php echo csrf_field(); ?>
                    <div class="recipient-dropzone" data-recipient-dropzone>
                        <span class="spreadsheet-symbol" aria-hidden="true">
                            <svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M27 5H12a3 3 0 0 0-3 3v32a3 3 0 0 0 3 3h24a3 3 0 0 0 3-3V17L27 5Z" />
                                <path d="M27 5v12h12M16 25h16M16 32h16M16 39h16" />
                            </svg>
                        </span>
                        
                        <h2><?php echo e(__('Drag & Drop File Here')); ?></h2>
                        <p><?php echo e(__('or')); ?></p>
                        
                        <input class="visually-hidden" id="recipients-file" name="recipients_file" type="file" accept=".xlsx,.xls,.csv" aria-hidden="true" tabindex="-1" data-recipient-file>
                        <button class="file-picker" type="button" data-recipient-picker><?php echo e(__('Choose File')); ?></button>
                        <p class="format-copy"><?php echo e(__('Formats: XLSX, XLS, or CSV')); ?><br><?php echo e(__('Maximum size: 10 MB')); ?></p>
                        <span class="selected-file-copy recipient-uploading" data-recipient-uploading hidden></span>
                    </div>
                </form>

                <aside class="recipient-import-preview">
                    <?php $__errorArgs = ['recipients_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="form-error recipient-error" role="alert"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    
                    <h2><?php echo e(__('Data preview')); ?> <span>(<?php echo e(count($recipients)); ?>)</span></h2>
                    
                    <div class="recipient-preview-scroll" data-preview-scroll>
                        <table class="recipient-table recipient-table--preview">
                            
                            <thead>
                                <tr><th scope="col"><?php echo e(__('No.')); ?></th><th scope="col"><?php echo e(__('Recipient Name')); ?></th><th scope="col"><?php echo e(__('Note')); ?></th></tr>
                            </thead>
                            
                            <tbody id="recipient-preview-rows">
                                <?php $__empty_1 = true; $__currentLoopData = $recipients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $recipient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr data-preview-row <?php if($index >= 10): ?> hidden <?php endif; ?>>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($recipient['name']); ?></td>
                                        <td><?php echo e($recipient['note']); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr class="preview-empty"><td colspan="3"><?php echo e(__('No data yet')); ?></td></tr>
                                <?php endif; ?>
                            </tbody>

                        </table>
                    </div>

                    <button class="preview-toggle" type="button" aria-expanded="false" aria-controls="recipient-preview-rows" data-preview-toggle <?php if(count($recipients) <= 10): ?> hidden <?php endif; ?>>
                        <span data-preview-label><?php echo e(__('Show All')); ?></span>
                        <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <path d="m4 6 4 4 4-4" />
                        </svg>
                    </button>

                    <form class="import-actions" method="POST" action="<?php echo e(route('recipients.next')); ?>">
                        <?php echo csrf_field(); ?>

                        <a class="secondary-button" href="<?php echo e(route('home')); ?>">
                            <svg viewBox="0 0 24 24" fill="none"
                                stroke="currentColor" stroke-width="2"
                                stroke-linecap="round" stroke-linejoin="round"
                                aria-hidden="true">
                                <path d="M19 12H5M12 19l-7-7 7-7"/>
                            </svg>
                            <?php echo e(__('Back')); ?>

                        </a>

                        <button class="primary-button" type="submit" <?php if(!$canAdvanceImport): echo 'disabled'; endif; ?>>
                            <?php echo e(__('Continue')); ?>

                            <svg viewBox="0 0 24 24" fill="none"
                                stroke="currentColor" stroke-width="2"
                                stroke-linecap="round" stroke-linejoin="round"
                                aria-hidden="true">
                                <path d="M5 12h14M13 6l6 6-6 6"/>
                            </svg>
                        </button>
                    </form>
                    <?php if(session('recipient_data_source') !== 'import'): ?>
                        <p class="form-error" role="status"><?php echo e(__('Upload an Excel or CSV file before continuing.')); ?></p>
                    <?php endif; ?>
                </aside>
            </section>
        </main>
    </div>
</body>
</html><?php /**PATH C:\Users\Sora\Documents\Certificate Project\Certificate\resources\views/recipients/index.blade.php ENDPATH**/ ?>