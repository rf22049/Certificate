
<?php
    $wizardSteps = [
        1 => __('Upload Template'),
        2 => __('Upload Data'),
        3 => __('Certificate Number'),
        4 => __('Edit Certificate'),
        5 => __('Review'),
    ];

    $previousStep = session('previous_wizard_step');
    $showSteps = $showSteps ?? true;
    $showExcel = $showExcel ?? false;
?>

<header class="topbar">
    <a class="brand" href="<?php echo e(route('home')); ?>" aria-label="<?php echo e(__('ProCert home')); ?>">
        <img
            class="brand-logo"
            src="<?php echo e(asset('images/procert_logo_transparent.png')); ?>"
            alt="ProCert"
        >
    </a>

    <div class="topbar-actions">
        <?php if($showExcel): ?>
            <a
                class="excel-button"
                href="<?php echo e(asset('images/templates/template_sertif.xlsx')); ?>"
                download
            >
                <span>▤</span>
                <?php echo e(__('Excel Template')); ?>

            </a>
        <?php endif; ?>

        
        <form
            class="language-picker"
            method="POST"
            action="<?php echo e(route('language.update')); ?>"
        >
            <?php echo csrf_field(); ?>

            <label class="visually-hidden" for="locale">
                <?php echo e(__('Language')); ?>

            </label>

            <select
                id="locale"
                name="locale"
                aria-label="<?php echo e(__('Language')); ?>"
                onchange="this.form.submit()"
            >
                <option value="id" <?php if(app()->getLocale() === 'id'): echo 'selected'; endif; ?>>
                    Bahasa Indonesia
                </option>

                <option value="en" <?php if(app()->getLocale() === 'en'): echo 'selected'; endif; ?>>
                    English
                </option>
            </select>
        </form>

        
        <button
            class="theme-toggle"
            type="button"
            data-theme-toggle
            data-label-dark="<?php echo e(__('Switch to dark mode')); ?>"
            data-label-light="<?php echo e(__('Switch to light mode')); ?>"
            aria-label="<?php echo e(__('Switch color theme')); ?>"
            title="<?php echo e(__('Switch color theme')); ?>"
            aria-pressed="false"
        >
            
            <svg
                data-theme-icon="moon"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="1.8"
                stroke-linecap="round"
                stroke-linejoin="round"
                aria-hidden="true"
            >
                <path d="M20.2 15.3A8.5 8.5 0 0 1 8.7 3.8 8.6 8.6 0 1 0 20.2 15.3Z"/>
            </svg>

            
            <svg
                data-theme-icon="sun"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="1.8"
                stroke-linecap="round"
                stroke-linejoin="round"
                aria-hidden="true"
                hidden
            >
                <circle cx="12" cy="12" r="4"/>
                <path d="M12 2v2m0 16v2M4.93 4.93l1.42 1.42m11.3 11.3 1.42 1.42M2 12h2m16 0h2M4.93 19.07l1.42-1.42m11.3-11.3 1.42-1.42"/>
            </svg>
        </button>
    </div>
</header>

<?php
    $procertTranslations = [
        'uploading' => __('Uploading...'),
        'uploadingFile' => __('Uploading :name...'),

        'recipientName' => __('Recipient name, row :number'),
        'note' => __('Note, row :number'),

        'deleteRow' => __('Delete row'),
        'deleteRowNumber' => __('Delete row :number'),

        'showAll' => __('Show All'),
        'showLess' => __('Show Less'),

        'previewPrefix' => __('Preview'),
    ];
?>

<script>
    window.procertTranslations = <?php echo e(\Illuminate\Support\Js::from($procertTranslations)); ?>;
</script>

<?php if($showSteps): ?>
    <nav class="steps" aria-label="<?php echo e(__('Certificate creation steps')); ?>">
        <ol class="steps-list">
            <?php $__currentLoopData = $wizardSteps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stepNumber => $stepLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $isComplete = $stepNumber < $currentStep;
                    $isActive = $stepNumber === $currentStep;

                    $stepClass = $isActive
                        ? 'is-active'
                        : ($isComplete ? 'is-complete' : '');

                    $animateCheck = $isComplete
                        && $previousStep !== null
                        && $stepNumber === (int) $previousStep;

                    $animateConnectorForward = $previousStep !== null
                        && $stepNumber === (int) $previousStep
                        && $stepNumber < $currentStep;

                    $animateConnectorBackward = $previousStep !== null
                        && $stepNumber === (int) $currentStep
                        && $currentStep < (int) $previousStep;

                    $animateRegression = $previousStep !== null
                        && $stepNumber === (int) $previousStep
                        && $currentStep < (int) $previousStep;
                ?>

                <li
                    class="step <?php echo e($stepClass); ?> <?php echo e($animateCheck ? 'animate-check' : ''); ?> <?php echo e($animateRegression ? 'animate-regression' : ''); ?>"
                    <?php if($isActive): ?> aria-current="step" <?php endif; ?>
                >
                    <span class="step-number">
                        <?php if($isComplete): ?>
                            <svg
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="2.5"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                aria-hidden="true"
                            >
                                <path d="m5 12 4 4L19 6"/>
                            </svg>
                        <?php else: ?>
                            <?php echo e($stepNumber); ?>

                        <?php endif; ?>
                    </span>

                    <span class="step-label"><?php echo e($stepLabel); ?></span>
                </li>

                <?php if($stepNumber < count($wizardSteps)): ?>
                    <li
                        class="step-connector
                            <?php echo e($stepNumber < $currentStep ? 'is-complete' : ''); ?>

                            <?php echo e($animateConnectorForward ? 'just-completed' : ''); ?>

                            <?php echo e($animateConnectorBackward ? 'just-reversed' : ''); ?>"
                        aria-hidden="true"
                    >
                        <span></span>
                    </li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
    </nav>
<?php endif; ?>
<?php /**PATH C:\Users\Sora\Documents\Certificate Project\Certificate\resources\views/partials/wizard-header.blade.php ENDPATH**/ ?>