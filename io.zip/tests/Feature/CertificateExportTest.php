<?php

namespace Tests\Feature;

use App\Services\CertificatePdfGenerator;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use setasign\Fpdi\PdfParser\StreamReader;
use setasign\Fpdi\Tfpdf\Fpdi;
use Tests\TestCase;
use ZipArchive;

class CertificateExportTest extends TestCase
{
    use RefreshDatabase;

    public function test_pdf_export_downloads_one_unicode_pdf_page_per_recipient(): void
    {
        $this->withImageTemplate();

        $response = $this->get(route('certificate-export.pdf'));

        $response->assertOk();
        $response->assertDownload('certificates.pdf');

        $content = $response->streamedContent();
        $this->assertStringStartsWith('%PDF-', $content);

        $pdf = new Fpdi('P', 'pt');
        $this->assertSame(2, $pdf->setSourceFile(StreamReader::createByString($content)));
        $this->assertDatabaseHas('certificate_number_usages', [
            'year' => 2025,
            'number' => 21,
        ]);
    }

    public function test_pdf_generator_uses_the_recipient_specific_text_box(): void
    {
        $this->withImageTemplate();
        $template = session('template');
        $template['path'] = Storage::disk('local')->path($template['path']);
        $recipient = ['name' => 'Ayu Lestari', 'note' => 'Peserta'];
        $numberSettings = ['year' => 2025, 'month' => 7, 'start_number' => 21];
        $editSettings = [
            'syncTextBoxes' => false,
            'global' => [
                'name' => ['x' => 50, 'y' => 45, 'font_size' => 24, 'bold' => true],
                'number' => ['x' => 50, 'y' => 75, 'font_size' => 14],
            ],
            'individual' => [
                0 => [
                    'textBoxes' => [[
                        'id' => 'text-one',
                        'content' => 'Teks Ayu',
                        'font_family' => 'Manrope',
                        'font_size' => 20,
                        'color' => '#4042A4',
                        'alignment' => 'center',
                        'bold' => false,
                        'italic' => false,
                        'underline' => false,
                        'x' => 35,
                        'y' => 82,
                    ]],
                ],
            ],
        ];
        $generator = app(CertificatePdfGenerator::class);
        $original = $generator->generateOne(
            $template,
            $recipient,
            0,
            $numberSettings,
            $editSettings,
        );
        $editSettings['individual'][0]['textBoxes'][0]['content'] = 'Teks berbeda';
        $editSettings['individual'][0]['textBoxes'][0]['x'] = 75;

        $changed = $generator->generateOne(
            $template,
            $recipient,
            0,
            $numberSettings,
            $editSettings,
        );

        $this->assertNotSame($original, $changed);
    }

    public function test_pdf_generator_uses_a_different_certificate_number_for_each_recipient_index(): void
    {
        $this->withImageTemplate();

        $template = session('template');
        $template['path'] = Storage::disk('local')->path($template['path']);

        $recipient = [
            'name' => 'Ayu Lestari',
            'note' => '',
        ];

        $numberSettings = [
            'year' => 2025,
            'month' => 7,
            'start_number' => 21,
            'fields' => [
                [
                    'label' => 'Number',
                    'type' => 'number',
                    'value' => '',
                ],
            ],
            'separator' => '/',
        ];

        $generator = app(CertificatePdfGenerator::class);

        $firstCertificate = $generator->generateOne(
            $template,
            $recipient,
            0,
            $numberSettings,
            [],
        );

        $secondCertificate = $generator->generateOne(
            $template,
            $recipient,
            1,
            $numberSettings,
            [],
        );

        $this->assertNotSame(
            $firstCertificate,
            $secondCertificate,
        );
    }

    public function test_zip_export_contains_a_pdf_for_each_recipient(): void
    {
        $this->withImageTemplate();

        $response = $this->get(route('certificate-export.zip'));

        $response->assertOk();
        $response->assertDownload('certificates.zip');
        $this->assertDatabaseHas('certificate_number_usages', [
            'year' => 2025,
            'number' => 21,
        ]);

        $archive = new ZipArchive;
        $archivePath = $response->baseResponse->getFile()->getPathname();

        try {
            $this->assertSame(true, $archive->open($archivePath));
            $this->assertSame(4, $archive->numFiles);
            $this->assertIsInt($archive->locateName('Ayu Lestari/'));
            $this->assertIsInt($archive->locateName('Bima Öztürk/'));
            $this->assertStringStartsWith('%PDF-', $archive->getFromName('Ayu Lestari/certificate.pdf'));
            $this->assertStringStartsWith('%PDF-', $archive->getFromName('Bima Öztürk/certificate.pdf'));
            $this->assertFalse($archive->locateName('certificate.pdf'));
            $this->assertTrue($archive->close());
            unset($archive);
            gc_collect_cycles();
        } finally {
            if (is_file($archivePath)) {
                @unlink($archivePath);
            }
        }
    }

    public function test_zip_export_creates_a_unique_folder_for_each_recipient_with_a_matching_name(): void
    {
        Storage::fake('local');
        $path = UploadedFile::fake()->image('template.png', 1200, 800)
            ->store('certificate-templates', 'local');
        $this->withExportSession($path, 'image/png', [
            ['name' => 'A', 'note' => ''],
            ['name' => 'A', 'note' => ''],
        ]);

        $response = $this->get(route('certificate-export.zip'));

        $response->assertOk();
        $archive = new ZipArchive;
        $archivePath = $response->baseResponse->getFile()->getPathname();

        try {
            $this->assertSame(true, $archive->open($archivePath));
            $this->assertSame(4, $archive->numFiles);
            $this->assertIsInt($archive->locateName('A/'));
            $this->assertIsInt($archive->locateName('A (2)/'));
            $this->assertStringStartsWith('%PDF-', $archive->getFromName('A/certificate.pdf'));
            $this->assertStringStartsWith('%PDF-', $archive->getFromName('A (2)/certificate.pdf'));
            $this->assertTrue($archive->close());
            unset($archive);
            gc_collect_cycles();
        } finally {
            if (is_file($archivePath)) {
                @unlink($archivePath);
            }
        }
    }

    public function test_pdf_export_uses_an_uploaded_pdf_as_the_certificate_background(): void
    {
        Storage::fake('local');
        $template = new Fpdi('L', 'pt', [842, 595]);
        $template->AddPage('L', [842, 595]);
        $template->AddFont('DejaVuSans', '', 'DejaVuSans.ttf', true);
        $template->SetFont('DejaVuSans', '', 20);
        $template->Text(100, 100, 'Original PDF template');
        Storage::disk('local')->put(
            'certificate-templates/template.pdf',
            $template->Output('S'),
        );
        $this->withExportSession('certificate-templates/template.pdf', 'application/pdf');

        $response = $this->get(route('certificate-export.pdf'));

        $response->assertOk();
        $response->assertDownload('certificates.pdf');
        $pdf = new Fpdi('P', 'pt');
        $this->assertSame(2, $pdf->setSourceFile(
            StreamReader::createByString($response->streamedContent()),
        ));
    }

    public function test_export_requires_a_selected_template(): void
    {
        $response = $this->get(route('certificate-export.pdf'));

        $response->assertNotFound();
    }

    private function withImageTemplate(): void
    {
        Storage::fake('local');
        $path = UploadedFile::fake()->image('template.png', 1200, 800)
            ->store('certificate-templates', 'local');

        $this->withExportSession($path, 'image/png');
    }

    private function withExportSession(string $templatePath, string $mime, ?array $recipients = null): void
    {
        $this->withSession([
            'template' => [
                'source' => 'upload',
                'path' => $templatePath,
                'mime' => $mime,
            ],
            'recipients' => $recipients ?? [
                ['name' => 'Ayu Lestari', 'note' => 'Peserta'],
                ['name' => 'Bima Öztürk', 'note' => 'Panitia'],
            ],
            'certificate_number_settings' => [
                'year' => 2025,
                'month' => 7,
                'start_number' => 21,
            ],
            'certificate_edit_settings' => [
                'syncTextBoxes' => false,
                'global' => [
                    'name' => ['x' => 50, 'y' => 45, 'font_size' => 24, 'bold' => true],
                    'number' => ['x' => 50, 'y' => 75, 'font_size' => 14],
                ],
                'individual' => [
                    0 => [
                        'textBoxes' => [[
                            'id' => 'text-one',
                            'content' => 'Teks Ayu',
                            'font_family' => 'Manrope',
                            'font_size' => 20,
                            'color' => '#4042A4',
                            'alignment' => 'center',
                            'bold' => false,
                            'italic' => false,
                            'underline' => false,
                            'x' => 35,
                            'y' => 82,
                        ]],
                    ],
                    1 => [
                        'name' => ['x' => 60, 'y' => 45],
                        'textBoxes' => [[
                            'id' => 'text-two',
                            'content' => 'Teks Bima',
                            'font_family' => 'Manrope',
                            'font_size' => 16,
                            'color' => '#4042A4',
                            'alignment' => 'left',
                            'bold' => false,
                            'italic' => false,
                            'underline' => false,
                            'x' => 60,
                            'y' => 90,
                        ]],
                    ],
                ],
            ],
        ]);
    }
}
